################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.c 

C_DEPS += \
./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.d 

OBJS += \
./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.o 


# Each subdirectory must supply rules for building sources it contributes
Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/%.o Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/%.su Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/%.cyclo: ../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/%.c Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MLX90614/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MCP9600/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/DRV8833/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/TMC2209/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Limit_Switches/Inc" -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Middlewares-2f-ST-2f-STM32_USB_Device_Library-2f-Class-2f-CDC-2f-Src

clean-Middlewares-2f-ST-2f-STM32_USB_Device_Library-2f-Class-2f-CDC-2f-Src:
	-$(RM) ./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.cyclo ./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.d ./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.o ./Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Src/usbd_cdc.su

.PHONY: clean-Middlewares-2f-ST-2f-STM32_USB_Device_Library-2f-Class-2f-CDC-2f-Src

