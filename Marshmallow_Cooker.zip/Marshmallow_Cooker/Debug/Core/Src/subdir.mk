################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Core/Src/DRV8833.cpp \
../Core/Src/MCP9600.cpp \
../Core/Src/MLX90614.cpp \
../Core/Src/TMC2209.cpp \
../Core/Src/Task_Cooker.cpp \
../Core/Src/Task_R_Motor.cpp \
../Core/Src/Task_Temps.cpp \
../Core/Src/Task_UI.cpp \
../Core/Src/Task_Z_Motor.cpp \
../Core/Src/main.cpp \
../Core/Src/r_encoder_driver.cpp \
../Core/Src/r_motor_driver.cpp \
../Core/Src/z_limit_switches.cpp \
../Core/Src/z_motor_driver.cpp 

C_SRCS += \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c 

C_DEPS += \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d 

OBJS += \
./Core/Src/DRV8833.o \
./Core/Src/MCP9600.o \
./Core/Src/MLX90614.o \
./Core/Src/TMC2209.o \
./Core/Src/Task_Cooker.o \
./Core/Src/Task_R_Motor.o \
./Core/Src/Task_Temps.o \
./Core/Src/Task_UI.o \
./Core/Src/Task_Z_Motor.o \
./Core/Src/main.o \
./Core/Src/r_encoder_driver.o \
./Core/Src/r_motor_driver.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o \
./Core/Src/z_limit_switches.o \
./Core/Src/z_motor_driver.o 

CPP_DEPS += \
./Core/Src/DRV8833.d \
./Core/Src/MCP9600.d \
./Core/Src/MLX90614.d \
./Core/Src/TMC2209.d \
./Core/Src/Task_Cooker.d \
./Core/Src/Task_R_Motor.d \
./Core/Src/Task_Temps.d \
./Core/Src/Task_UI.d \
./Core/Src/Task_Z_Motor.d \
./Core/Src/main.d \
./Core/Src/r_encoder_driver.d \
./Core/Src/r_motor_driver.d \
./Core/Src/z_limit_switches.d \
./Core/Src/z_motor_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.cpp Core/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MLX90614/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MCP9600/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/DRV8833/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/TMC2209/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Limit_Switches/Inc" -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MLX90614/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MCP9600/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/DRV8833/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/TMC2209/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Motor_Driver/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Limit_Switches/Inc" -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/DRV8833.cyclo ./Core/Src/DRV8833.d ./Core/Src/DRV8833.o ./Core/Src/DRV8833.su ./Core/Src/MCP9600.cyclo ./Core/Src/MCP9600.d ./Core/Src/MCP9600.o ./Core/Src/MCP9600.su ./Core/Src/MLX90614.cyclo ./Core/Src/MLX90614.d ./Core/Src/MLX90614.o ./Core/Src/MLX90614.su ./Core/Src/TMC2209.cyclo ./Core/Src/TMC2209.d ./Core/Src/TMC2209.o ./Core/Src/TMC2209.su ./Core/Src/Task_Cooker.cyclo ./Core/Src/Task_Cooker.d ./Core/Src/Task_Cooker.o ./Core/Src/Task_Cooker.su ./Core/Src/Task_R_Motor.cyclo ./Core/Src/Task_R_Motor.d ./Core/Src/Task_R_Motor.o ./Core/Src/Task_R_Motor.su ./Core/Src/Task_Temps.cyclo ./Core/Src/Task_Temps.d ./Core/Src/Task_Temps.o ./Core/Src/Task_Temps.su ./Core/Src/Task_UI.cyclo ./Core/Src/Task_UI.d ./Core/Src/Task_UI.o ./Core/Src/Task_UI.su ./Core/Src/Task_Z_Motor.cyclo ./Core/Src/Task_Z_Motor.d ./Core/Src/Task_Z_Motor.o ./Core/Src/Task_Z_Motor.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/r_encoder_driver.cyclo ./Core/Src/r_encoder_driver.d ./Core/Src/r_encoder_driver.o ./Core/Src/r_encoder_driver.su ./Core/Src/r_motor_driver.cyclo ./Core/Src/r_motor_driver.d ./Core/Src/r_motor_driver.o ./Core/Src/r_motor_driver.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su ./Core/Src/z_limit_switches.cyclo ./Core/Src/z_limit_switches.d ./Core/Src/z_limit_switches.o ./Core/Src/z_limit_switches.su ./Core/Src/z_motor_driver.cyclo ./Core/Src/z_motor_driver.d ./Core/Src/z_motor_driver.o ./Core/Src/z_motor_driver.su

.PHONY: clean-Core-2f-Src

