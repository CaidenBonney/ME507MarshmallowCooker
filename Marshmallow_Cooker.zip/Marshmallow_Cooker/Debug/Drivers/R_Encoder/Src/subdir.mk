################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Drivers/R_Encoder/Src/r_encoder_driver.cpp 

OBJS += \
./Drivers/R_Encoder/Src/r_encoder_driver.o 

CPP_DEPS += \
./Drivers/R_Encoder/Src/r_encoder_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/R_Encoder/Src/%.o Drivers/R_Encoder/Src/%.su Drivers/R_Encoder/Src/%.cyclo: ../Drivers/R_Encoder/Src/%.cpp Drivers/R_Encoder/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MLX90614/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MCP9600/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/DRV8833/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Motor/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Motor/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/TMC2209/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Limit_Switches/Inc" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-R_Encoder-2f-Src

clean-Drivers-2f-R_Encoder-2f-Src:
	-$(RM) ./Drivers/R_Encoder/Src/r_encoder_driver.cyclo ./Drivers/R_Encoder/Src/r_encoder_driver.d ./Drivers/R_Encoder/Src/r_encoder_driver.o ./Drivers/R_Encoder/Src/r_encoder_driver.su

.PHONY: clean-Drivers-2f-R_Encoder-2f-Src

