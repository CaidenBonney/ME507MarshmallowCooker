################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Drivers/Z_Motor/Src/z_motor_driver.cpp 

OBJS += \
./Drivers/Z_Motor/Src/z_motor_driver.o 

CPP_DEPS += \
./Drivers/Z_Motor/Src/z_motor_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/Z_Motor/Src/%.o Drivers/Z_Motor/Src/%.su Drivers/Z_Motor/Src/%.cyclo: ../Drivers/Z_Motor/Src/%.cpp Drivers/Z_Motor/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MLX90614/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/MCP9600/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/DRV8833/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Motor/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Motor/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/TMC2209/Inc" -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/Z_Limit_Switches/Inc" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-Z_Motor-2f-Src

clean-Drivers-2f-Z_Motor-2f-Src:
	-$(RM) ./Drivers/Z_Motor/Src/z_motor_driver.cyclo ./Drivers/Z_Motor/Src/z_motor_driver.d ./Drivers/Z_Motor/Src/z_motor_driver.o ./Drivers/Z_Motor/Src/z_motor_driver.su

.PHONY: clean-Drivers-2f-Z_Motor-2f-Src

