################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.cpp 

OBJS += \
./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.o 

CPP_DEPS += \
./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/Adafruit_MLX90614/Src/%.o Drivers/Adafruit_MLX90614/Src/%.su Drivers/Adafruit_MLX90614/Src/%.cyclo: ../Drivers/Adafruit_MLX90614/Src/%.cpp Drivers/Adafruit_MLX90614/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"/Users/caidenbonney/STM32CubeIDE/ME507MarshmallowCooker/Marshmallow_Cooker/Drivers/R_Encoder/Inc" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-Adafruit_MLX90614-2f-Src

clean-Drivers-2f-Adafruit_MLX90614-2f-Src:
	-$(RM) ./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.cyclo ./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.d ./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.o ./Drivers/Adafruit_MLX90614/Src/Adafruit_MLX90614.su

.PHONY: clean-Drivers-2f-Adafruit_MLX90614-2f-Src

